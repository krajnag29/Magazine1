﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace Magazine
{
    class Program
    {
        public static string token { get; set; }
        public static string baseUrl = "http://magazinestore.azurewebsites.net/api";
        public static List<ResponseMagazine> lstMagazine = new List<ResponseMagazine>();
        public static List<string> subscribers = new List<string>();
        public static SubscriberBody subscriberBody = new SubscriberBody();
        static void Main(string[] args)
        {
            token = GetToken().Result;

            var categories = GetCategories().Result;
            foreach(var category in categories)
            {
                var magazineCategory = GetMagazinesByCategory(category).Result;
                magazineCategory.ForEach(mc => lstMagazine.Add(new ResponseMagazine { id = mc.id, category=mc.category }));
            }
            
            var subscriberslst = GetSubscribers().Result;

            

            var groupdedMagazineCategory =
                            (from i in lstMagazine
                             group i by i.category into g
                             select new MagazineCategory { CategoryName =  g.Key, MagazineId = g.Select(a => a.id).ToList() }).ToList();



            subscriberBody.subscribers = new List<string>();
            Console.Write("Subsccriber Ids: ");
            Console.WriteLine();
            foreach (var subscriber in subscriberslst)
            {
                if (subscriber.magazineIds.Intersect(groupdedMagazineCategory[0].MagazineId).Any() &&
                    subscriber.magazineIds.Intersect(groupdedMagazineCategory[1].MagazineId).Any() &&
                    subscriber.magazineIds.Intersect(groupdedMagazineCategory[2].MagazineId).Any())
                {
                    subscriberBody.subscribers.Add(subscriber.id);
                    Console.WriteLine(subscriber.id);
                }

            }

            var answer = PostAnswer().Result;

            Console.Write("===============");
            Console.WriteLine();
            Console.WriteLine("Success : " +answer.success);
            Console.WriteLine("Token : " + answer.token);
            Console.WriteLine("Time Taken : " + answer.data.totalTime);
            Console.WriteLine("Answer Correct : " + answer.data.answerCorrect);

            Console.ReadKey();
        }

        #region APICalls
        public static async Task<string> GetToken()
        {
            //var authCredential = Encoding.UTF8.GetBytes("{userTest}:{passTest}");
            using (var client = new HttpClient())
            {


                //client.DefaultRequestHeaders.Authorization =
                //    new AuthenticationHeaderValue("Basic", Convert.ToBase64String(authCredential));
                client.BaseAddress = new Uri(baseUrl);
                HttpResponseMessage response = await client.GetAsync(baseUrl + "/token");

                
                    var readTask = response.Content.ReadAsStringAsync().ConfigureAwait(false);
                    var rawResponse = readTask.GetAwaiter().GetResult();
                    var myJObject = JObject.Parse(rawResponse);
                    return myJObject.SelectToken("token").Value<string>();
                
            }
        }

        public static async Task<List<string>> GetCategories()
        {
            //var authCredential = Encoding.UTF8.GetBytes("{userTest}:{passTest}");
            using (var client = new HttpClient())
            {


                //client.DefaultRequestHeaders.Authorization =
                //    new AuthenticationHeaderValue("Basic", Convert.ToBase64String(authCredential));
                client.BaseAddress = new Uri(baseUrl);
                HttpResponseMessage response = await client.GetAsync(baseUrl + "/categories/" + token);


                var readTask = response.Content.ReadAsStringAsync().ConfigureAwait(false);
                var rawResponse = readTask.GetAwaiter().GetResult();
                Category categories = JsonConvert.DeserializeObject<Category>(rawResponse);
                return categories.data;
            }
        }

        public static async Task<List<Magazine>> GetMagazinesByCategory(string category)
        {
            //var authCredential = Encoding.UTF8.GetBytes("{userTest}:{passTest}");
            using (var client = new HttpClient())
            {


                //client.DefaultRequestHeaders.Authorization =
                //    new AuthenticationHeaderValue("Basic", Convert.ToBase64String(authCredential));
                client.BaseAddress = new Uri(baseUrl);
                HttpResponseMessage response = await client.GetAsync(baseUrl + "/magazines/" + token + "/" + category);


                var readTask = response.Content.ReadAsStringAsync().ConfigureAwait(false);
                var rawResponse = readTask.GetAwaiter().GetResult();
                Magazines categories = JsonConvert.DeserializeObject<Magazines>(rawResponse);
                return categories.data;
            }
        }

        public static async Task<List<Subscribe>> GetSubscribers()
        {
            //var authCredential = Encoding.UTF8.GetBytes("{userTest}:{passTest}");
            using (var client = new HttpClient())
            {


                //client.DefaultRequestHeaders.Authorization =
                //    new AuthenticationHeaderValue("Basic", Convert.ToBase64String(authCredential));
                client.BaseAddress = new Uri(baseUrl);
                HttpResponseMessage response = await client.GetAsync(baseUrl + "/subscribers/" + token);


                var readTask = response.Content.ReadAsStringAsync().ConfigureAwait(false);
                var rawResponse = readTask.GetAwaiter().GetResult();
                Subscribers subscribers = JsonConvert.DeserializeObject<Subscribers>(rawResponse);
                return subscribers.data;
            }
        }

        public static async Task<Root> PostAnswer()
        {
            //var authCredential = Encoding.UTF8.GetBytes("{userTest}:{passTest}");
            using (var client = new HttpClient())
            {


                
                client.BaseAddress = new Uri(baseUrl);
                var myContent = JsonConvert.SerializeObject(subscriberBody);
                var buffer = System.Text.Encoding.UTF8.GetBytes(myContent);
                var byteContent = new ByteArrayContent(buffer);
                byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                HttpResponseMessage response = await client.PostAsync(baseUrl + "/answer/" + token, byteContent);


                var readTask = response.Content.ReadAsStringAsync().ConfigureAwait(false);
                var rawResponse = readTask.GetAwaiter().GetResult();
                var myJObject = JObject.Parse(rawResponse);
                Root answer = JsonConvert.DeserializeObject<Root>(rawResponse);
                return answer;
            }
        }

        #endregion


        #region Models
        public class Category
        {
            public List<string> data { get; set; }
        }

        
        public class Magazine
        {
            public int id { get; set; }
            public string name { get; set; }
            public string category { get; set; }
        }

        public class Magazines
        {
            public List<Magazine> data { get; set; }
        }

        public class ResponseMagazine
        {
            public int id { get; set; }
            public string name { get; set; }
            public string category { get; set; }
        }

        public class Subscribe
        {
            public string id { get; set; }
            public string firstName { get; set; }
            public string lastName { get; set; }
            public List<int> magazineIds { get; set; }
        }

        public class Subscribers
        {
            public List<Subscribe> data { get; set; }
        }

        public class MagazineCategory
        {
            public string CategoryName { get; set; }

            public List<int> MagazineId { get; set; }
        }

        public class SubscriberBody
        {
            public List<string> subscribers { get; set; }
        }

        public class Data
        {
            public string totalTime { get; set; }
            public bool answerCorrect { get; set; }
            public object shouldBe { get; set; }
        }

        public class Root
        {
            public Data data { get; set; }
            public bool success { get; set; }
            public string token { get; set; }
        }

        #endregion
    }
}
